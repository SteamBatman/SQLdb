package com.example.sqlite_test;

public class Data {
    String name;
    String surname;
    int year;

    public Data(String name, String surname, int year) {
        this.name = name;
        this.surname = surname;
        this.year = year;
    }
}

